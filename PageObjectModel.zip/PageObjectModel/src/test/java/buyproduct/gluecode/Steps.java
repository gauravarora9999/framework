package buyproduct.gluecode;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import constants.AppConstants;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pageobjects.CartPage;
import pageobjects.CheckoutPage;
import pageobjects.HomePage;
import pageobjects.ProductListingPage;
 
public class Steps {
	WebDriver driver;
	HomePage home;
	ProductListingPage productListingPage;
	CartPage cartPage;
	CheckoutPage checkoutPage;
	
	@Given("^user is on Home Page$")
	public void user_is_on_Home_Page(){
		System.setProperty("webdriver.chrome.driver",AppConstants.chromeDriverLocation);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://www.shop.demoqa.com");
	}
 
	@When("^he search for \"([^\"]*)\"$")
	public void he_search_for(String product)  {
		home = new HomePage(driver);
		home.perform_Search(product);
	}
 
	@And("^choose to buy the first item$")
	public void choose_to_buy_the_first_item() {
		productListingPage = new ProductListingPage(driver);
		productListingPage.select_Product(0);
		productListingPage.clickOn_AddToCart();		
	}
 
	@And("^moves to checkout from mini cart$")
	public void moves_to_checkout_from_mini_cart(){
		cartPage = new CartPage(driver);
		cartPage.clickOn_Cart();
		cartPage.clickOn_ContinueToCheckout();	
	}
	
	@And("^enter personal details on checkout page$")
	public void enter_personal_details_on_checkout_page() throws InterruptedException {
		checkoutPage = new CheckoutPage(driver);
		checkoutPage.fill_PersonalDetails();	
	}
	
	@And("^select same delivery address$")
	public void select_same_delivery_address() throws InterruptedException{
		checkoutPage.check_ShipToDifferentAddress(false);
	}
	
	@And("^select payment method as \"([^\"]*)\" payment$")
	public void select_payment_method_as_payment(String arg1){
		checkoutPage.select_PaymentMethod("CheckPayment");
	}
 
	@And("^place the order$")
	public void place_the_order() throws InterruptedException {
		checkoutPage.check_TermsAndCondition(true);
		checkoutPage.clickOn_PlaceOrder();
		driver.quit();
	}	
}